echo gradle wrapper placeholder
